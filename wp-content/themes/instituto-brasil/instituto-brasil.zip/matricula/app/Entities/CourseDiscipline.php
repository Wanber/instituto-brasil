<?php

namespace Prominas\Entities;

use Illuminate\Database\Eloquent\Model;

class CourseDiscipline extends Model
{
    protected $table        = 'tb_curso_disciplina';
    protected $connection   = 'mysql2';
    protected $fillable     = [];

}
