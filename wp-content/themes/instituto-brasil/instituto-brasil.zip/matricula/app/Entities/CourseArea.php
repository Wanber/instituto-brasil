<?php

namespace Prominas\Entities;

use Illuminate\Database\Eloquent\Model;

class CourseArea extends Model
{
    protected $table        = 'tb_curso_area';
    protected $connection   = 'mysql2';
    protected $fillable     = [];
}
