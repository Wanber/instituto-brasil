<?php

namespace Prominas\Events;

abstract class Event
{
    //
}
