var offset_scroll_nav = 30;

jQuery(function ($) {

    //scroll suave em links para sessoes
    $('a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        $('html,body').animate({scrollTop:$(this.hash).offset().top-offset_scroll_nav}, 800);
    });

    //fixa menu ao descer
    $(window).bind('scroll', function () {
        if ($(window).scrollTop() > offset_scroll_nav) {
            $('#menu').addClass('fix');
        } else {
            $('#menu').removeClass('fix');
        }
    });

});

function redireciona(url) {
    window.location.href = url;
}