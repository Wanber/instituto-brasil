<div class="sec-page">

    <div class="w-container">
        <div class="w-row">
            <article class="article" itemscope itemtype="http://schema.org/BlogPosting" itemprop="BlogPost">

                <div class="post-text">
                    <h2 class="post-title entry-title" itemprop="headline">
                        <?php _e('Não Encontrado', 'defato'); ?>
                    </h2>
                </div>

                <article class="post-content entry-content" itemprop="text">

                    <p>
                        <?php _e('Você chegou a uma página que não está existente ou já foi removida ', ' defato'); ?>.
                    </p>

                </article><!-- .post-content -->

            </article><!-- .article -->
        </div>
    </div>
</div>